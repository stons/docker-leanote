tinymce.addI18n('zh',{
	codeLang: "代码语言",
	toggleCode: "ctrl+shift+c 切换代码"
});
